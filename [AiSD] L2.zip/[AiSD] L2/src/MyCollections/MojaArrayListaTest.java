package MyCollections;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

public class MojaArrayListaTest {

	@Test
	public void testSize() {
		
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Assert.assertTrue(array.size()==0);
		Assert.assertFalse(array.size()!=0);
	}

	@Test
	public void testLength() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Assert.assertTrue(array.length()==10);
		Assert.assertFalse(array.length()!=10);
	}
	@Test
	public void testGet() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Integer integer=2;
		array.add(integer);
		Assert.assertNotNull(array.get(0));
		Assert.assertEquals(integer, array.get(0));
	}
	@Test
	public void testRemove() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Integer integer=2;
		array.add(integer);
		Assert.assertEquals(integer, array.remove(0));
	}
	
	@Test
	public void testClear() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Integer integer=2;
		for(int i = 0; i<10;i++)
		array.add(integer);
		Assert.assertNotNull(array.get(4));
		array.clear();
		Assert.assertNull(array.get(0));
	}

	@Test
	public void testIndexOf() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Integer integer=2;
		for(int i = 0; i<10;i++)
			array.add(integer);
		Integer int2 = 3;
		array.add(int2);
		Assert.assertTrue(array.indexOf(int2)==10);
	}
	
	@Test
	public void testSet() {
		MojaArrayLista<Integer> array = new MojaArrayLista<>();
		Integer integer=2;
		for(int i = 0; i<10;i++)
		array.add(integer);
		Integer int2 = 3;
		int rozmiar = array.size();
		array.set(4, int2);
		Assert.assertTrue(array.indexOf(int2)==4);
		Assert.assertTrue(array.size()==rozmiar );
	}
	
}
