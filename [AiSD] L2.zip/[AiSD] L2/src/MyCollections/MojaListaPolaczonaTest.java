package MyCollections;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Assert;
import org.junit.Test;
import MyCollections.*;
public class MojaListaPolaczonaTest {

	@Test
	public void testSize() {
		
			
		MojaListaPolaczona<Integer> list = new MojaListaPolaczona<>();
			Assert.assertTrue(list.getSize()==0);
			Assert.assertFalse(list.getSize()!=0);
			Integer int1=3;
			list.addEnd(int1);
			Assert.assertTrue(list.getSize()==1);
			Assert.assertFalse(list.getSize()!=1);
		
	}
	
	@Test
	public void testAddAtPos() {
		MojaListaPolaczona<Integer> list = new MojaListaPolaczona<>();
		Integer int1=3;
		for(int t = 0; t<10 ; t++)
		list.addEnd(int1);
		Integer integer = 1;
		list.addAtPos(integer, 5);
		Assert.assertTrue(list.getSize() == 11);
		
	}
	@Test
	public void testDeleteAtPos() {
		MojaListaPolaczona<Integer> list = new MojaListaPolaczona<>();
		Integer int1=3;
		for(int t = 0; t<10 ; t++)
		list.addEnd(int1);
		list.deleteAtPos(5);
		Assert.assertTrue(list.getSize() == 9);
	}
	
	@Test
	public void testAddAll() {
		MojaListaPolaczona<Integer> list = new MojaListaPolaczona<>();
		Integer[] tab = {3,1,2,6,3,5,2,4,2,5};
		Assert.assertTrue(list.getSize() == 0);
		list.addEndAll(tab);
		Assert.assertTrue(list.getSize() == 10);
	}
	
	@Test
	public void testAddStart() {
		MojaListaPolaczona<Integer> list = new MojaListaPolaczona<>();
		Integer[] tab = {3,1,2,6,3,5,2,4,2,5};
		Integer integer = 0;
		Assert.assertTrue(list.getSize() == 0);
		list.addEndAll(tab);
		Assert.assertTrue(list.getSize() == 10);
		list.addStart(integer);
		Assert.assertTrue(list.getStart() == 0);
	}
	
	
}
